from animal import *

class Bird(Animal):
    #Konstraktor Properti
    def __init__(self, nama, makanan, hidup, berkembang_biak, warna, paruh):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.warna = warna
        self.paruh = paruh

    #Method
    def info_bird(self):
        super().info_animal()
        print("warna\t\t\t: ", self.warna, "\njenis paruh\t\t: ", self.paruh)

bird = Bird("Burung Elang", "Daging", "Ditebing", "Menghasilkan Telur", "Coklat", "Beongkok dan Lancip")
print("## info bird ##")
bird.info_bird()

bird = Bird("Burung Gagak", "Biji-bijian", "DiHutan", "Menghasilkan Telur", "Hitam", "Bengkok")
print("## info bird ##")
bird.info_bird()

bird = Bird("Burung Cendrawasih", "Biji-bijian", "Dipohon", "Menghasilkan Telur", "Coklat/orange/dll", "Bengkok")
print("## info bird ##")
bird.info_bird()