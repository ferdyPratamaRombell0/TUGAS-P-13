from animal import *

class Fish(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, bernapas, habitat):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.bernapas = bernapas
        self.habitat = habitat
        
    def info_Fish(self):
        super().info_animal()
        print("bernapas\t\t:",self.bernapas,"\nhabitat\t\t\t:",self.habitat)

fish = Fish("Hiu", "Daging", "Dilaut", "Melahirkan","Insang","Air Asin")
print("## info Fish ##\n")
fish.info_Fish()

arwana = Fish("Arwana", "Daging", "Dilaut", "Melahirkan","Insang","Air Asin")
print("## info Fish ##\n")
arwana.info_Fish()

aligator = Fish("Aligator", "Daging", "Dilaut", "Melahirkan","Insang", "Air Tawar")
print("## info Fish ##\n")
aligator.info_Fish()




